#ifndef TILE_H
#define TILE_H

class Tile {
public:
    Tile();
};

#endif

