#include "Tile.h"

Tile::Tile() {
}
