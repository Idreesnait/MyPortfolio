Run the following: g++ -o CircleOfLife main.cpp Board.cpp Player.cpp Tile.cpp
Then follow that with: ./BoardGame 
note: windows might be BoardGame.exe though I'm not sure 
